Steps to run

javac FifteenPuzzleAStar.java

java FifteenPuzzleAStar
Enter the initial state
1 0 2 4 5 6 7 8 9 11 12 10 13 14 15 3
