Steps to run

javac IDFSA.java

java IDFSA
Enter the initial state
1 0 2 4 5 6 7 8 9 11 12 10 13 14 15 3



Note:
Memory limitation is very low, So some test cases will throw out of bounds exception although correctly implememnted.
